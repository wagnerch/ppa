/* This header file is used in 4.3BSD to define `struct lastlog',
   which we define in <bits/utmp.h>.  */

#include <utmp.h>
